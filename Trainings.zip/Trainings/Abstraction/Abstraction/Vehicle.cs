﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstraction
{
    public abstract class Vehicle
    {
        // These are abstract methods; the derived classes will provide the implementation.
        public abstract void Start();
        public abstract void Stop();
    }
    //Concrete Implementations
    public class Car : Vehicle
    {
        public override void Start()
        {
            Console.WriteLine("Car is starting with a key turn.");
        }
        public override void Stop()
        {
            Console.WriteLine("Car is stopping using its brakes.");
        }
    }
    public class Bus : Vehicle
    {
        public override void Start()
        {
            Console.WriteLine("Electric train is starting by powering up.");
        }
        public override void Stop()
        {
            Console.WriteLine("Electric train is stopping by cutting off the power.");
        }
    }
}
