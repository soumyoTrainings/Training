﻿namespace Abstraction
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Vehicle myCar = new Car();
            Vehicle myTrain = new Bus();
            StartVehicle(myCar);  // Output: Car is starting with a key turn.
            StartVehicle(myTrain); // Output: Electric train is starting by powering up.
            Console.Read();
        }
        static void Main(string[] args, string[] args1)
        {
            Vehicle myCar = new Car();
            Vehicle myTrain = new Bus();
            StartVehicle(myCar);  // Output: Car is starting with a key turn.
            StartVehicle(myTrain); // Output: Electric train is starting by powering up.
            Console.Read();
        }
        static void StartVehicle(Vehicle vehicle)
        {
            vehicle.Start();
        }


        static void Messaging()
        {
            IMessagingService emailService = new EmailService();
            IMessagingService smsService = new SmsService();
            IMessagingService pushService = new PushNotificationService();
            SendAlert(emailService, "example@example.com", "Hello via Email!");
            SendAlert(smsService, "1234567890", "Hello via SMS!");
            SendAlert(pushService, "User123", "Hello via Push Notification!");
            Console.Read();
        }
        static void SendAlert(IMessagingService service, string recipient, string message)
        {
            service.SendMessage(recipient, message);
        }
    }
}
