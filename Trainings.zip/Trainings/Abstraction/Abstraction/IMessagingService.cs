﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstraction
{
    public interface IMessagingService
    {
        void SendMessage(string recipient, string message);
    }
    public class EmailService : IMessagingService
    {
        public void SendMessage(string recipient, string message)
        {
            Console.WriteLine($"Sending Email to {recipient}: {message}");
            // Here, you'd have the actual logic to send an email.
        }
    }
    public class SmsService : IMessagingService
    {
        public void SendMessage(string recipient, string message)
        {
            Console.WriteLine($"Sending SMS to {recipient}: {message}");
            // Here, you'd have the actual logic to send an SMS.
        }
    }
    public class PushNotificationService : IMessagingService
    {
        public void SendMessage(string recipient, string message)
        {
            Console.WriteLine($"Sending Push Notification to {recipient}: {message}");
            // Here, you'd have the actual logic to send a push notification.
        }
    }
}
