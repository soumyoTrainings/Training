﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistributedCache.Model
{
    internal class CustomModel
    {
        public string? CorrelationId { get; set; }
        public string? AuthToken { get; set; }
        public string? PluginId { get; set; }
        public string? Message { get; set; }
    }
}
