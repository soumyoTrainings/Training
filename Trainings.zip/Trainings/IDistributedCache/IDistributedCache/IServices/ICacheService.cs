﻿using DistributedCache.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistributedCache.IServices
{
    internal interface ICacheService
    {
        void StoreJson(string jsonString);
        CustomModel RetrieveByCorrelationId(string correlationId);
    }
}
