﻿using DistributedCache.IServices;
using DistributedCache.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;

namespace DistributedCache.Services
{
    internal class CacheService
    {
        private readonly IDistributedCache _cache;
        public CacheService(IDistributedCache cache)
        {
            _cache = cache;
        }
        
        public void StoreJson(string jsonString)
        {
            if (string.IsNullOrWhiteSpace(jsonString))
                throw new ArgumentException("JSON string cannot be null or empty.", nameof(jsonString));
            var model = JsonSerializer.Deserialize<CustomModel>(jsonString);
            if (model == null)
                throw new InvalidOperationException("Failed to deserialize the JSON string.");

            // Serialize the model back to JSON for storage
            var serializedModel = JsonSerializer.Serialize(model);

            // Store in IDistributedCache with a unique key
            _cache.SetString(model.CorrelationId!, serializedModel, new DistributedCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(1) // Set expiration time as needed
            });
        }
        public CustomModel RetrieveByCorrelationId(string correlationId)
        {
            if (string.IsNullOrWhiteSpace(correlationId))
                throw new ArgumentException("CorrelationId cannot be null or empty.", nameof(correlationId));

            // Retrieve the serialized JSON from the cache
            var serializedModel = _cache.GetString(correlationId);
            if (string.IsNullOrEmpty(serializedModel))
                return null;

            // Deserialize and return the model
            return JsonSerializer.Deserialize<CustomModel>(serializedModel);
        }

    }
}
