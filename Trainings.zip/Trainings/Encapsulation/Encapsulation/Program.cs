﻿namespace Encapsulation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount myAccount = new BankAccount(500);
            // Balance becomes 700
            myAccount.Deposit(200);
            // Outputs: 700
            Console.WriteLine(myAccount.Balance);
            // Balance becomes 600
            myAccount.Withdraw(100);
            // Outputs: 600
            // myAccount.balance = -1000;  // This would be an error, as the balance field is private and inaccessible directly.
            //Console.WriteLine(myAccount.balance); 
            Console.WriteLine(myAccount.Balance); 

            Console.Read();
            
            
            GetProduct();

        }
        static void GetProduct() {
            // Create a new product
            Product product = new Product
            {
                Name = "Wireless Mouse",
                Price = 29.99m,
                StockQuantity = 50
            };

            // Display initial product details
            Console.WriteLine($"Product: {product.Name}, Price: {product.Price}, Stock: {product.StockQuantity}");

            // Sell some quantity
            try
            {
                product.Sell(10);
                Console.WriteLine($"Stock after sale: {product.StockQuantity}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            // Restock the product
            try
            {
                product.Restock(20);
                Console.WriteLine($"Stock after restock: {product.StockQuantity}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            // Try setting invalid values
            try
            {
                product.Price = -5; // This will throw an exception
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine(ex.Message);
            }

            try
            {
                product.StockQuantity = -10; // This will also throw an exception
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            
            Console.Read();
        }
    }
}
