﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Encapsulation
{
    public class Product
    {
        // Private fields
        private string name;
        private decimal price;
        private int stockQuantity;

        // Public property for Name
        public string Name
        {
            get { return name; }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    name = value;
                }
                else
                {
                    throw new ArgumentException("Product name cannot be empty.");
                }
            }
        }

        // Public property for Price
        public decimal Price
        {
            get { return price; }
            set
            {
                if (value >= 0)
                {
                    price = value;
                }
                else
                {
                    throw new ArgumentException("Price cannot be negative.");
                }
            }
        }

        // Public property for StockQuantity
        public int StockQuantity
        {
            get { return stockQuantity; }
            set
            {
                if (value >= 0)
                {
                    stockQuantity = value;
                }
                else
                {
                    throw new ArgumentException("Stock quantity cannot be negative.");
                }
            }
        }

        // Method to sell a product
        public void Sell(int quantity)
        {
            if (quantity <= 0)
            {
                throw new ArgumentException("Quantity to sell must be greater than zero.");
            }

            if (quantity > stockQuantity)
            {
                throw new InvalidOperationException("Insufficient stock to complete the sale.");
            }

            stockQuantity -= quantity;
            Console.WriteLine($"{quantity} of {name} sold. Remaining stock: {stockQuantity}");
        }

        // Method to restock the product
        public void Restock(int quantity)
        {
            if (quantity <= 0)
            {
                throw new ArgumentException("Quantity to restock must be greater than zero.");
            }

            stockQuantity += quantity;
            Console.WriteLine($"{quantity} of {name} restocked. New stock: {stockQuantity}");
        }
    }
}
