﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace CustomMW
{
    public class CustomHealthCheckMiddlewaree
    {
        //public ILogger<CustomHealthCheckMiddlewaree> _logger;
        public RequestDelegate _next;

        public CustomHealthCheckMiddlewaree(RequestDelegate next)
        {
            _next = next;
//_logger = logger;
           // _logger.LogInformation("Custom Middleware Executed");
        }
        public async Task Invoke(HttpContext context)
        {
            // Middleware logic here
            await context.Response.WriteAsync("Custom Middleware Executed\n");
            await _next(context);
        }
    }
}
