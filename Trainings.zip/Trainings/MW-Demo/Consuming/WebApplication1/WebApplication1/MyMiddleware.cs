﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace WebApplication1
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class MyMiddleware
    {
        private readonly RequestDelegate _next;
        //private readonly IConfiguration _configuration;
        //private readonly IServiceCollection _serviceCollection;
        //private readonly IEndpointRouteBuilder _endpoints;
        private string _filePath;

        public MyMiddleware(RequestDelegate next, string filePath)
        {
            _next = next;
            //_configuration = configuration;
            _filePath = filePath;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            if (context.Request.Path.StartsWithSegments("/health"))
            {
                var healthStatus = CheckHealth();
                if (healthStatus)
                {
                    context.Response.StatusCode = 200; // OK
                    await context.Response.WriteAsync("Healthy");
                }
                else
                {
                    context.Response.StatusCode = 503; // Service Unavailable
                    await context.Response.WriteAsync("Unhealthy");
                }
            }
            else
            {
                await _next(context);
            }
            await _next(context);
        }

        private bool CheckHealth()
        {
            // Add health check logic (DB, external services, etc.)
            return true; // For simplicityyy
        }
    }
}