[CmdletBinding()]
Param(
	[string]$StartupProject = "src/Hyland.ContentFederation.Gateway.Api",
	[string]$Project = "src/Hyland.ContentFederation.Gateway",
	[string]$Context = "Book",
	[string]$ConnectionString = "Host=localhost;Port=5432;Database=blueprint;Uid=postgres;Pwd=password;",
	[string]$Name
)

if (([string]::IsNullOrEmpty($Context))) {
  throw "Context param is required."
}

if (([string]::IsNullOrEmpty($Name))) {
  throw "Name param is required"
}

if (-not (Get-Command -Name 'dotnet' -CommandType Application -ErrorAction SilentlyContinue)) {
	throw "This project requires dotnet core but it could not be found. Please install dotnet core and ensure it is available on your PATH"
}

$OutputDir = "Datastores/Migrations/$Context"
$ContextType = $Context + "DbContext"
$FullOutputPath = $Project + "/" + $OutputDir

Write-Output "Creating migrations..."
$PreviousMigrationName = get-childitem $FullOutputPath -Filter *.sql | Sort-Object Name | Select-Object -last 1 | Select-Object BaseName | ForEach-Object { $_.BaseName.substring($_.BaseName.indexOf("_") + 1) }
 
Invoke-Expression "& dotnet ef migrations add -o `"$OutputDir`" -c `"$ContextType`" -s `"$StartupProject`" -p `"$Project`" -v `"$Name`" -- `"$Connectionstring`" "
$NewMigrationFileName = get-childitem $FullOutputPath -Filter 2*.cs | Where-Object BaseName -notlike "*.Designer" | Sort-Object Name | Select-Object -last 1 | Select-Object BaseName | ForEach-Object { $_.BaseName.substring($_.BaseName.indexOf(".") + 1) }
Invoke-Expression "& dotnet ef migrations script --idempotent -c `"$ContextType`" -s `"$StartupProject`" -p `"$Project`" -v `"$PreviousMigrationName`" `"$Name`" -o `"$FullOutputPath/$NewMigrationFileName.sql`" -- `"$Connectionstring`" "
exit $LASTEXITCODE
