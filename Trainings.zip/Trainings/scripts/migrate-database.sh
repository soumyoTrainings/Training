#!/bin/sh

RootDir=${1:-"/var/app"}
ConnectionString=${2:-"postgres://postgres:password@host.docker.internal:5432"}
Database=${3:-"blueprint"}

#echo "SELECT 'CREATE DATABASE $Database' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '$Database')\gexec" | psql $ConnectionString -d postgres
#if [ $? -ne 0 ]; then
#	echo "Error creating database $Database"
#	exit 1
#fi

for filename in $RootDir/src/Hyland.ContentFederation.Gateway/Datastores/Migrations/**/*.sql; do
	echo $filename && psql -q $ConnectionString/$Database -f $filename -v ON_ERROR_STOP=1;
	if [ $? -ne 0 ]; then
		echo "Error in migration script $filename"
		exit 1
	fi
done

