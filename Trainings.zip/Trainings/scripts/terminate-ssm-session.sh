#!/bin/sh

SESSION_ID=$(find . -wholename '**/session-info-*.json' -exec cat {} \; | jq -r '."session-id"')
echo $SESSION_ID
echo "aws ssm terminate-session --session-id $SESSION_ID"
aws ssm terminate-session --session-id $SESSION_ID