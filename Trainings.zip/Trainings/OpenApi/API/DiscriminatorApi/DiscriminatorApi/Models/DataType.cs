﻿using System.Text.Json.Serialization;

namespace DiscriminatorApi.Models
{
    [JsonPolymorphic(TypeDiscriminatorPropertyName = "type")]
    [JsonDerivedType(typeof(DataTypeBoolean), nameof(DataTypeBoolean))]
    [JsonDerivedType(typeof(DataTypeInteger), nameof(DataTypeInteger))]
    [JsonDerivedType(typeof(DataTypeDecimal), nameof(DataTypeDecimal))]
    [JsonDerivedType(typeof(DataTypeString), nameof(DataTypeString))]
    [JsonDerivedType(typeof(DataTypeDate), nameof(DataTypeDate))]
    [JsonDerivedType(typeof(DataTypeDateTime), nameof(DataTypeDateTime))]
    [JsonDerivedType(typeof(DataTypeCurrency), nameof(DataTypeCurrency))]
    public class DataType
    {
        public string? Type { get; set; }
    }
    public class DataTypeBoolean : DataType
    {
        public bool? DefaultValue { get; set; }
    }
    public class DataTypeInteger : DataType
    {
        public int? DefaultValue { get; set; }
        public int? MinValue { get; set; }
        public int? MaxValue { get; set; }
    }
    public class DataTypeString : DataType
    {
        public string? DefaultValue { get; set; }
        public int? MaxCharLength { get; set; }
        public int? MinCharLength { get; set; }
        public int? MaxByteLength { get; set; }
        public int? MinByteLength { get; set; }
    }
    public class DataTypeDecimal : DataType
    {
        public double? DefaultValue { get; set; }
        public double? MinValue { get; set; }
        public double? MaxValue { get; set; }
        public int? NumberOfSignificantDigits { get; set; }
    }
    public class DataTypeDateTime : DataType
    {
        public DateTime? DefaultValue { get; set; }
        public DateTime? MinValue { get; set; }
        public DateTime? MaxValue { get; set; }
        public string? Timezone { get; set; }
    }
    public class DataTypeDate : DataType
    {
        public DateOnly? DefaultValue { get; set; }
        public DateOnly? MinValue { get; set; }
        public DateOnly? MaxValue { get; set; }
    }
    public class DataTypeCurrency : DataType
    {
        public double? DefaultValue { get; set; }
        public double? MinValue { get; set; }
        public double? MaxValue { get; set; }
    }

}
