﻿using System.Text.Json.Serialization;

namespace DiscriminatorApi.Models
{
    //[JsonConverter(typeof(JsonPolymorphicConverter<BaseItem>))]
    [JsonPolymorphic(TypeDiscriminatorPropertyName = "type")]
    [JsonDerivedType(typeof(DerivedA), nameof(DerivedA))]
    [JsonDerivedType(typeof(DerivedB), nameof(DerivedB))]
    public class BaseItem
    {
        public string? Id { get; set; }
        public string? Type { get; set; }
    }

    public class DerivedA : BaseItem
    {
        public string? SpecialPropertyA { get; set; }
    }

    public class DerivedB : BaseItem
    {
        //public string? SpecialPropertyA { get; set; }
        public int? SpecialPropertyB { get; set; }
    }
}
