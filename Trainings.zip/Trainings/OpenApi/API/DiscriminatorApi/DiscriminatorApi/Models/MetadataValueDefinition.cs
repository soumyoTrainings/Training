﻿using System.Text.Json.Serialization;

namespace DiscriminatorApi.Models
{
    
    public class MetadataValueDefinition
    {
        public string? Id { get; set; }
        public string? LocalizedName { get; set; }
        public string? SystemName { get; set; }
        public bool? IsProtected { get; set; }
        public bool? IsFormatted { get; set; }
        public bool? IsMasked { get; set; }
        public DataType? DataTypeInfo { get; set; }
        public bool? HasValidValues { get; set; }
        public bool? ValueMustExist { get; set; }
    }
}
