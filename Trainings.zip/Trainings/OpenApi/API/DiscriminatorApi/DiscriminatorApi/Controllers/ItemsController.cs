﻿using DiscriminatorApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace DiscriminatorApi.Controllers
{
    [ApiController]
    [Route("api/items")]
    public class ItemsController : ControllerBase
    {
        [HttpGet("base-items")]
        public ActionResult<IEnumerable<BaseItem>> GetBaseItems()
        {
            var items = new List<BaseItem>
        {
            new DerivedA { Id = "1", Type = "derivedA", SpecialPropertyA = "Value A" },
            new DerivedB { Id = "2", Type = "derivedB", SpecialPropertyB = 123 }
        };
            return Ok(items);
        }

        [HttpGet("data-types")]
        public ActionResult<IEnumerable<DataType>> GetDataTypes()
        {
            var dataTypes = new List<DataType>
        {
            new DataTypeBoolean { Type = "DataTypeBoolean", DefaultValue = true },
            new DataTypeInteger { Type = "DataTypeInteger", DefaultValue = 10, MinValue = 1, MaxValue = 100 },
            new DataTypeString { Type = "DataTypeString", DefaultValue = "Default Text", MaxCharLength = 50, MinCharLength=1, MaxByteLength=0, MinByteLength=0 },
            new DataTypeCurrency { Type = "DataTypeCurrency", DefaultValue = 99.99, MinValue = 10, MaxValue = 1000 }
        };
            return Ok(dataTypes);
        }

        [HttpGet("metadata-items")]
        public IActionResult GetMetadataItems()
        {
            var metadataItems = new List<MetadataValueDefinition>
            {
                new MetadataValueDefinition
                {
                    Id = "1",
                    LocalizedName = "Item One",
                    SystemName = "System_Item_1",
                    IsProtected = true,
                    IsFormatted = false,
                    IsMasked = false,
                    DataTypeInfo = new DataTypeString { Type = "DataTypeString", DefaultValue = "Sample", MaxCharLength = 50, MinCharLength=1, MaxByteLength=0, MinByteLength=0 },
                    //DataTypeInfo=new DataTypeBoolean{Type="DataTypeBoolean",DefaultValue=true},
                    HasValidValues = true,
                    ValueMustExist = false
                },
                new MetadataValueDefinition
                {
                    Id = "2",
                    LocalizedName = "Item Two",
                    SystemName = "System_Item_2",
                    IsProtected = false,
                    IsFormatted = true,
                    IsMasked = true,
                    DataTypeInfo = new DataTypeInteger { Type = "DataTypeInteger", DefaultValue = 20, MinValue = 5, MaxValue = 50 },
                    //DataTypeInfo=new DataTypeBoolean{Type="DataTypeBoolean",DefaultValue=true},
                    HasValidValues = false,
                    ValueMustExist = true
                }
            };

            return Ok(metadataItems);
        }
    }
}
