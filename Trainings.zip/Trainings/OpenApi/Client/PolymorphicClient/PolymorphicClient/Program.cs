﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json;

namespace PolymorphicClient
{

    class Program
    {
        static async Task Main(string[] args)
        {

            var httpclient = new HttpClient();
            var client = new Client("https://localhost:7036/", httpclient);
            var baseItems = await client.BaseItemsAsync();
            var dataTypeItems = await client.DataTypesAsync();

            foreach (var item in baseItems)
            {
                Console.WriteLine($"Id: {item.Id}, Type: {item.AdditionalProperties}");
                if (item is DerivedA derivedA)
                {
                    Console.WriteLine($"  SpecialPropertyA: {derivedA.SpecialPropertyA}");
                }
                else if (item is DerivedB derivedB)
                {
                    Console.WriteLine($"  SpecialPropertyB: {derivedB.SpecialPropertyB}");
                }
            }
            foreach (var dataType in dataTypeItems)
            {
                Console.WriteLine($"Type: {dataType.GetType}");
                switch (dataType)
                {
                    case DataTypeBoolean booleanType:
                        Console.WriteLine($"  Default Value: {booleanType.DefaultValue}");
                        break;
                    case DataTypeInteger integerType:
                        Console.WriteLine($"  Default Value: {integerType.DefaultValue}, Range: {integerType.MinValue} - {integerType.MaxValue}");
                        break;
                    case DataTypeString stringType:
                        Console.WriteLine($"  Default Value: {stringType.DefaultValue}, Max Length: {stringType.MaxCharLength}");
                        break;
                    case DataTypeDecimal decimalType:
                        Console.WriteLine($"  Default Value: {decimalType.DefaultValue}, Range: {decimalType.MinValue} - {decimalType.MaxValue}");
                        break;
                    case DataTypeDate dateType:
                        Console.WriteLine($"  Default Date: {dateType.DefaultValue}");
                        break;
                    case DataTypeDateTime dateTimeType:
                        Console.WriteLine($"  Default DateTime: {dateTimeType.DefaultValue}, Timezone: {dateTimeType.Timezone}");
                        break;
                    case DataTypeCurrency currencyType:
                        Console.WriteLine($"  Default Value: {currencyType.DefaultValue}, Range: {currencyType.MinValue} - {currencyType.MaxValue}");
                        break;
                }
            }

            var response = await client.MetadataItemsAsync();

            Console.WriteLine("Metadata Items:");
            foreach (var item in response)
            {
                Console.WriteLine($"ID: {item.Id}, Name: {item.LocalizedName}, DataType: {item.DataTypeInfo.GetType().Name}");
            }
        }
    }
}
