﻿using Microsoft.AspNetCore.WebUtilities;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text.Json;

namespace SigningPayload
{
    public class SignAgain
    {
        static void Main()
        {
            // 2. CF Gateway Signs Message
            var message = new Message(Guid.NewGuid().ToString());
            var messageBytes = JsonSerializer.SerializeToUtf8Bytes(message);
            var Keys = GenerateKeyPair();

            //var gatewayKeys = RSA.Create(2048);
            //var gatewayPrivateKey = gatewayKeys.ExportRSAPrivateKey();
            //var gatewayPublicKey = gatewayKeys.ExportRSAPublicKey();            

            var gatewayPrivateKey = Keys.PrivateKey;
            var gatewayPublicKey = Keys.PublicKey;
            var keyId = Keys.KeyId;

            string signedMessageFromGateway = SignMessage(new MemoryStream(messageBytes), gatewayPrivateKey, keyId);

            string finalMessageFromGateway = signedMessageFromGateway + "\n" + JsonSerializer.Serialize(message, new JsonSerializerOptions { WriteIndented = true });

            var isValid = VerifyMessage(new MemoryStream(messageBytes), signedMessageFromGateway, gatewayPublicKey);
        }
        static string SignMessage(Stream stream, string privateKey, string keyId /*byte[] privateKey*/)
        {
            try
            {
                using SHA256 sha256 = SHA256.Create();
                byte[] contentHash = sha256.ComputeHash(stream);
                string encodedContentHash = WebEncoders.Base64UrlEncode(contentHash);
                DateTime utcNow = DateTime.UtcNow;
                JwtPayload payload = new JwtPayload(
                    issuer: null,
                    audience: null,
                    claims: new List<Claim>(){
             new Claim("signatureType", "v1+0"),
             new Claim("signature", encodedContentHash),
             new Claim("brokerId", Guid.NewGuid().ToString()),
                     },
                    notBefore: utcNow.AddSeconds(-15),
                    expires: utcNow.AddSeconds(30),
                    issuedAt: utcNow
                    );

                using var rsa = RSA.Create();

                byte[] privateKeyBytes = WebEncoders.Base64UrlDecode(privateKey);
                rsa.ImportPkcs8PrivateKey(privateKeyBytes, out _);

                //rsa.ImportRSAPrivateKey(Convert.FromBase64String(Convert.ToBase64String(privateKey)), out _);

                // rsa.ImportRSAPrivateKey(Convert.FromBase64String(LoadPrivateKey()), out _);

                var securityKey = new RsaSecurityKey(rsa) { KeyId = keyId };
                var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.RsaSha256);
                JwtHeader header = new JwtHeader(credentials);

                JwtSecurityToken jwtSecurityToken = new JwtSecurityToken(header, payload);

                string payloadValidationHeader = new JwtSecurityTokenHandler().WriteToken(jwtSecurityToken);
                return payloadValidationHeader;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Signature failed: {ex.Message}");
                return null;
            }

        }
        static PayloadWithBrokerInformation? VerifyMessage(Stream stream, string signedMessage, string publicKey /*byte[] publicKey*/)
        {
            try
            {
                MemoryStream payloadStream = new MemoryStream();
                using SHA256 sha256 = SHA256.Create();
                //CryptoStream cryptoStream = new CryptoStream(payloadStream, sha256, CryptoStreamMode.Write);


                //cryptoStream.FlushFinalBlock();
                // byte[] hash = sha256.Hash!;
                byte[] contentHash = sha256.ComputeHash(stream);
                string payloadEncodedHashValue = WebEncoders.Base64UrlEncode(contentHash);

                var handler = new JwtSecurityTokenHandler();
                var rsa = RSA.Create();

                byte[] publicKeyBytes = WebEncoders.Base64UrlDecode(publicKey);
                rsa.ImportSubjectPublicKeyInfo(publicKeyBytes, out _);

                //rsa.ImportRSAPublicKey(publicKey, out _);

                var securityKey = new RsaSecurityKey(rsa);

                var validationParams = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = securityKey,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.FromSeconds(30), // Allow slight clock drift
                    ValidateAudience = false,
                    ValidateIssuer = false
                };

                var claim = handler.ValidateToken(signedMessage, validationParams, out SecurityToken _);
                var payloadChecksumType = claim.FindFirst("signatureType")!.Value;
                var payloadSignatureValue = claim.FindFirst("signature")!.Value;
                var brokerId = claim.FindFirst("brokerId")!.Value;

                if (brokerId == null)
                {
                    return null;
                }

                // todo: validate that brokerId is associated with kid

                if (payloadChecksumType == null || payloadChecksumType != "v1+0")
                {
                    // handle error unexpected payload validation type.
                    return null;
                }

                if (payloadSignatureValue == null)
                {
                    // handle error unexpected payload validation value.
                    return null;
                }

                if (payloadSignatureValue == null || payloadSignatureValue != payloadEncodedHashValue)
                {
                    // handle error unexpected payload validation value
                    return null;
                }

                return new PayloadWithBrokerInformation { BrokerId = brokerId, PayloadStream = payloadStream };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Signature verification failed: {ex.Message}");
                return null;
            }
        }
        record Message(string guid);
        static string LoadPrivateKey()
        {
            // Replace this with actual key retrieval logic (from secure storage or config)
            using var rsa = RSA.Create();
            rsa.KeySize = 2048;
            return Convert.ToBase64String(rsa.ExportRSAPrivateKey());
        }
        public class PayloadWithBrokerInformation// : IDisposable, IAsyncDisposable
        {
            public required string BrokerId { get; init; }
            public required Stream PayloadStream { get; init; }

            public void Dispose()
            {
                PayloadStream?.Dispose();
            }

            public ValueTask DisposeAsync()
            {
                return PayloadStream?.DisposeAsync() ?? ValueTask.CompletedTask;
            }
        }
        public static RsaKeyPairResult GenerateKeyPair()
        {
            RSA rsa = RSA.Create(2048);

            byte[] privateKeyBytes = rsa.ExportPkcs8PrivateKey();
            byte[] publicKeyBytes = rsa.ExportSubjectPublicKeyInfo();

            // Base64Url encode the keys
            string privateKey = WebEncoders.Base64UrlEncode(privateKeyBytes);
            string publicKey = WebEncoders.Base64UrlEncode(publicKeyBytes);

            // Create SHA256 checksum of the public key (used in KeyId)
            SHA256 sha256 = SHA256.Create();
            byte[] publicKeyHash = sha256.ComputeHash(publicKeyBytes);
            string publicKeyHashBase64 = Convert.ToBase64String(publicKeyHash);

            // Compose KeyId as "<UUID>-<checksum>"
            string keyId = $"{Guid.NewGuid()}-{publicKeyHashBase64}";

            return new RsaKeyPairResult(privateKey, publicKey, keyId);
        }
    }
    public class RsaKeyPairResult
    {
        public string PrivateKey { get; set; }
        public string PublicKey { get; set; }
        public string KeyId { get; set; }

        public RsaKeyPairResult(string privateKey, string publicKey, string keyId)
        {
            PrivateKey = privateKey;
            PublicKey = publicKey;
            KeyId = keyId;
        }
    }
}
