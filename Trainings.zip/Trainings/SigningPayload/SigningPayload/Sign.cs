﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace SigningPayload
{
    internal class Sign
    {
        static void Mainsss()
        {
            // 1. Retrieve Private Key and Key ID
            var privateKeyPem = LoadPrivateKey();
            var kid = "your-key-id"; // This should be fetched from a key store

            // 2. Construct Message Payload
            var payload = new Dictionary<string, object>
        {
            { "message", "Hello, Gateway!" },
            { "transactionId", "123456789" },
            { "amount", 99.99 }
        };

            // 3. Generate Field Checksums
            var signedFields = GenerateSignedFields(payload);

            // 4. Create JWT Payload with Signed Fields & Standard Claims
            var jwtPayload = new Dictionary<string, object>()
        {
            { "signedFields", signedFields },
            { "iat", DateTimeOffset.UtcNow.ToUnixTimeSeconds() },
            { "nbf", DateTimeOffset.UtcNow.ToUnixTimeSeconds() },
            { "exp", DateTimeOffset.UtcNow.AddMinutes(10).ToUnixTimeSeconds() }
        };

            // 5. Sign JWT
            string signedJwt = SignJwt(jwtPayload, privateKeyPem, kid);

            // 6. Prepend JWT to Message Body
            string finalMessage = signedJwt + "\n" + JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = true });

            // 7. Send Message (Example Output)
            Console.WriteLine("Final Signed Message:");
            Console.WriteLine(finalMessage);
        }

        static string LoadPrivateKey()
        {
            // Replace this with actual key retrieval logic (from secure storage or config)
            using var rsa = RSA.Create();
            rsa.KeySize = 2048;
            return Convert.ToBase64String(rsa.ExportRSAPrivateKey());
        }

        static Dictionary<string, object> GenerateSignedFields(Dictionary<string, object> payload)
        {
            var signedFields = new Dictionary<string, object>();

            foreach (var field in payload)
            {
                string fieldValue = field.Value.ToString() ?? string.Empty;
                byte[] fieldBytes = Encoding.UTF8.GetBytes(fieldValue);

                using var sha256 = SHA256.Create();
                byte[] hash = sha256.ComputeHash(fieldBytes);
                string checksum = Base64UrlEncode(hash);

                signedFields[field.Key] = new
                {
                    checksumAlgorithm = "Base64UrlEncodedSha256",
                    checksum = checksum
                };
            }

            return signedFields;
        }

        static string SignJwt(Dictionary<string, object> payload, string privateKeyPem, string kid)
        {
            using var rsa = RSA.Create();
            rsa.ImportRSAPrivateKey(Convert.FromBase64String(privateKeyPem), out _);

            var securityKey = new RsaSecurityKey(rsa) { KeyId = kid };
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.RsaSha256);

            var jwtHeader = new JwtHeader(credentials);
            var jwtPayload = new JwtPayload();
            foreach (var kvp in payload)
                jwtPayload.Add(kvp.Key, kvp.Value);
            var jwt = new JwtSecurityToken(jwtHeader, jwtPayload);

            return new JwtSecurityTokenHandler().WriteToken(jwt);
        }

        static string Base64UrlEncode(byte[] data)
        {
            return Convert.ToBase64String(data).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        }
    }
}
