﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace SigningPayload
{
    internal class Program
    {
        static void Maisn()
        {
            // 1. Generate or load RSA keys (In production, use stored keys)
            var gatewayKeys = RSA.Create(2048);
            var brokerKeys = RSA.Create(2048);

            // Public/Private Keys
            var gatewayPrivateKey = gatewayKeys.ExportRSAPrivateKey();
            var gatewayPublicKey = gatewayKeys.ExportRSAPublicKey();
            var brokerPrivateKey = brokerKeys.ExportRSAPrivateKey();
            var brokerPublicKey = brokerKeys.ExportRSAPublicKey();

            // 2. CF Gateway Signs Message
            var payload = new Dictionary<string, object>
        {
            { "message", "Data from Gateway to Broker" },
            { "transactionId", "TX123456" },
            { "amount", 150.00 }
        };

            string signedMessageFromGateway = SignMessage(payload, gatewayPrivateKey, "cf-gateway-key");
            string finalMessageFromGateway = signedMessageFromGateway + "\n" + JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = true });
            // 3. CF Broker Validates Gateway Message
            bool isValid = VerifyMessage(signedMessageFromGateway, gatewayPublicKey);

            if (!isValid)
            {
                Console.WriteLine(" ERROR: Message verification failed at CF Broker! Job not processed.");
                return;
            }
            Console.WriteLine("Message from CF Gateway validated successfully at CF Broker.");

            // 4. CF Broker Signs Response
            var brokerResponse = new Dictionary<string, object>
        {
            { "message", "Data from Broker to Gateway" },
            { "transactionId", "TX123456" },
            { "status", "Approved" }
        };

            string signedMessageFromBroker = SignMessage(brokerResponse, brokerPrivateKey, "cf-broker-key");
            string finalMessageFromBroker = signedMessageFromBroker + "\n" + JsonSerializer.Serialize(brokerResponse, new JsonSerializerOptions { WriteIndented = true });
            // 5. CF Gateway Validates Broker Message
            bool isBrokerMessageValid = VerifyMessage(signedMessageFromBroker, brokerPublicKey);

            if (!isBrokerMessageValid)
            {
                Console.WriteLine("ERROR: Message verification failed at CF Gateway! Response ignored.");
                return;
            }
            Console.WriteLine("Message from CF Broker validated successfully at CF Gateway.");
        }

        static string SignMessage(Dictionary<string, object> payload, byte[] privateKey, string kid)
        {
            using var rsa = RSA.Create();
            rsa.ImportRSAPrivateKey(privateKey, out _);
            var privateKeyPem = LoadPrivateKey();

            var securityKey = new RsaSecurityKey(rsa) { KeyId = kid };
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.RsaSha256);

            // Generate signed field checksums
            var signedFields = GenerateSignedFields(payload);

            // JWT Payload
            var jwtPayloads = new Dictionary<string, object>(payload)
        {
            { "signedFields", signedFields },
            { "iat", DateTimeOffset.UtcNow.ToUnixTimeSeconds() },
            { "nbf", DateTimeOffset.UtcNow.ToUnixTimeSeconds() },
            { "exp", DateTimeOffset.UtcNow.AddMinutes(10).ToUnixTimeSeconds() }
        };
            var jwtHeader = new JwtHeader(credentials);

            var jwtPayload = new JwtPayload();
            foreach (var kvp in jwtPayloads)
                jwtPayload.Add(kvp.Key, kvp.Value);
            
            var jwtToken = new JwtSecurityToken(jwtHeader, jwtPayload);

            return new JwtSecurityTokenHandler().WriteToken(jwtToken);
        }

        static bool VerifyMessage(string signedMessage, byte[] publicKey)
        {
            try
            {
                var handler = new JwtSecurityTokenHandler();
                var rsa = RSA.Create();
                rsa.ImportRSAPublicKey(publicKey, out _);
                var securityKey = new RsaSecurityKey(rsa);

                var validationParams = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = securityKey,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.FromSeconds(30), // Allow slight clock drift
                    ValidateAudience = false,
                    ValidateIssuer = false
                };

                handler.ValidateToken(signedMessage, validationParams, out _);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Signature verification failed: {ex.Message}");
                return false;
            }
        }
        static string LoadPrivateKey()
        {
            // Replace this with actual key retrieval logic (from secure storage or config)
            using var rsa = RSA.Create();
            rsa.KeySize = 2048;
            return Convert.ToBase64String(rsa.ExportRSAPrivateKey());
        }
        static Dictionary<string, object> GenerateSignedFields(Dictionary<string, object> payload)
        {
            var signedFields = new Dictionary<string, object>();

            foreach (var field in payload)
            {
                string fieldValue = field.Value.ToString() ?? string.Empty;
                byte[] fieldBytes = Encoding.UTF8.GetBytes(fieldValue);

                using var sha256 = SHA256.Create();
                byte[] hash = sha256.ComputeHash(fieldBytes);
                string checksum = Base64UrlEncode(hash);

                signedFields[field.Key] = new
                {
                    checksumAlgorithm = "Base64UrlEncodedSha256",
                    checksum = checksum
                };
            }

            return signedFields;
        }

        static string Base64UrlEncode(byte[] data)
        {
            return Convert.ToBase64String(data).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        }
    }
}
