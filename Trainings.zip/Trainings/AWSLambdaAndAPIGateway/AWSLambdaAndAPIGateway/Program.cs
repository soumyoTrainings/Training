
using Amazon.SQS;
using Amazon.SQS.Model;

namespace AWSLambdaAndAPIGateway
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            //builder.Services.AddAWSLambdaHosting(LambdaEventSource.HttpApi);
            builder.Services.AddAWSLambdaHosting(LambdaEventSource.RestApi);

            var app = builder.Build();

            //SQS Connection
            var sqsClient = new AmazonSQSClient();
            var message = new SendMessageRequest
            {
                QueueUrl = "https://sqs.us-east-1.amazonaws.com/156041437871/SQS-Queue",
                MessageBody = "Heelo From API"
            };


            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
