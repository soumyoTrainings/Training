﻿using Hyland.ContentFederation.Plugin.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using POCToTestService.Service_Interface;
using System.Reflection;

namespace POCToTestService
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var services = new ServiceCollection();
            var configuration = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .Build();
            // Load plugins
            var pluginDirectory = Path.Combine(AppContext.BaseDirectory, "Plugins");
            var assemblies = AppDomain.CurrentDomain.GetAssemblies();

            //Loading from dll
            foreach (var dllPath in Directory.GetFiles(pluginDirectory, "*.dll"))
            {
                var pluginAssembly = Assembly.LoadFrom(dllPath);
                var pluginType = pluginAssembly.GetTypes()
                    .FirstOrDefault(t => typeof(IPlugin).IsAssignableFrom(t) && !t.IsInterface);

                if (pluginType != null)
                {
                    var pluginInstance = (IPlugin)Activator.CreateInstance(pluginType);
                    pluginInstance.registerPlugin(configuration, services);
                }
            }

            //Loading from Nuget ref
            foreach (var assembly in assemblies)
            {
                // Find types that implement the IPlugin interface
                var pluginTypes = assembly.GetTypes()
                    .Where(t => typeof(IPlugin).IsAssignableFrom(t) && !t.IsInterface && !t.IsAbstract);

                foreach (var pluginType in pluginTypes)
                {
                    // Create an instance of the plugin and call RegisterPlugin
                    var pluginInstance = (IPlugin)Activator.CreateInstance(pluginType);
                    pluginInstance?.registerPlugin(configuration, services);

                    // Optionally, log the loaded plugin information
                    var pluginInfo = pluginInstance.GetPluginInfo();
                    Console.WriteLine($"Registered plugin: {pluginInfo.PluginType} (Version {pluginInfo.GetType})");
                }

                // Build service provider
                var serviceProvider = services.BuildServiceProvider();

                // Resolve and use services
                var myService = serviceProvider.GetService<IMyService>();
                myService?.DoWork();
            }
        }
    }
}
