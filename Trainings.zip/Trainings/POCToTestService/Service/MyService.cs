﻿using POCToTestService.Service_Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POCToTestService.Service
{
    internal class MyService : IMyService
    {
        public void DoWork()
        {
            throw new NotImplementedException();
        }
    }
}
