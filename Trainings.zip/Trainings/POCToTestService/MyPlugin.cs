﻿using Hyland.ContentFederation.Plugin.Interfaces;
using Hyland.ContentFederation.Plugin.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using POCToTestService.Service;
using POCToTestService.Service_Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POCToTestService
{
    public class MyPlugin: IPlugin
    {
        public PluginInfo GetPluginInfo()
        {
            throw new NotImplementedException();
        }

        public void registerPlugin(IConfiguration configuration, IServiceCollection services)
        {
            // Add services specific to this plugin
            services.AddSingleton<IMyService, MyService>();
        }

    }
}
