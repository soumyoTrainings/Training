﻿using Microsoft.Extensions.DependencyInjection;
using Plugin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlugin
{
    public class RegisterMyPluginAgain : IPlugin
    {
        public void RegisterPlugin(IServiceCollection services)
        {
            services.AddSingleton<IAnotherService, AnotherService>();
        }
    }
}
