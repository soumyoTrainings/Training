﻿using AnotherPlugin;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MyPlugin;
using Plugin;
using System.Reflection;

namespace PluginHost
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Setup configuration and services
            var configuration = new ConfigurationBuilder()
                .SetBasePath(AppContext.BaseDirectory)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .Build();
            var services = new ServiceCollection();

            var pluginSection = configuration.GetSection("Library:PluginPaths");

            //var pluginPaths = pluginSection.AsEnumerable()
            //                   .Where(kv => kv.Value != null)
            //                   .Select(kv => kv.Value)
            //                   .ToArray();

            var assemblies = AppDomain.CurrentDomain.GetAssemblies();

            // Load plugins dynamically from dll
            LoadPluginsFromdll(pluginSection.Value!, services);

            //Load plugins dynamically from Nuget

            LoadPluginsFromNuget(assemblies, services);

            // Build the service provider and resolve services
            var serviceProvider = services.BuildServiceProvider();

            // Example usage
            var myService = serviceProvider.GetService<MyPlugin.IAnotherService>();
            myService?.PerformAction();

            var anotherService = serviceProvider.GetService<AnotherPlugin.IMyService>();
            anotherService?.DoWork();
        }

        private static void LoadPluginsFromdll(string pluginSection, IServiceCollection services)
        {
            foreach (var dllPath in Directory.GetFiles(pluginSection!, "*.dll"))
            {
                if (!File.Exists(dllPath))
                {
                    Console.WriteLine($"Plugin file not found: {dllPath}");
                    continue;
                }

                // Load the assembly
                var assembly = Assembly.LoadFrom(dllPath);

                // Find all types implementing IPlugin
                var pluginTypes = assembly.GetTypes()
                    .Where(t => typeof(IPlugin).IsAssignableFrom(t) && !t.IsInterface && !t.IsAbstract);

                foreach (var pluginType in pluginTypes)
                {
                    // Create an instance of the plugin and register it
                    var pluginInstance = (IPlugin)Activator.CreateInstance(pluginType);
                    pluginInstance.RegisterPlugin(services);
                    Console.WriteLine($"Loaded plugin from dll: {pluginType.FullName}");
                }
            }
        }
        private static void LoadPluginsFromNuget(Assembly[]? assemblies, IServiceCollection services)
        {
            //Loading from Nuget ref
            foreach (var assembly in assemblies)
            {
                // Find types that implement the IPlugin interface
                var pluginTypes = assembly.GetTypes()
                    .Where(t => typeof(IPlugin).IsAssignableFrom(t) && !t.IsInterface && !t.IsAbstract);

                foreach (var pluginType in pluginTypes)
                {
                    // Create an instance of the plugin and call RegisterPlugin
                    var pluginInstance = (IPlugin)Activator.CreateInstance(pluginType);
                    //pluginInstance?.registerPlugin(configuration, services);

                    pluginInstance?.RegisterPlugin(services);

                    // Optionally, log the loaded plugin information
                    //var pluginInfo = pluginInstance.GetPluginInfo();
                    // Console.WriteLine($"Registered plugin: {pluginInfo.PluginType} (Version {pluginInfo.GetType})");

                    Console.WriteLine($"Loaded plugin from Nuget: {pluginType.FullName}");
                }

                //// Build service provider
                //var serviceProvider = services.BuildServiceProvider();

                //// Resolve and use services
                //var myService = serviceProvider.GetService<IMyService>();
                //myService?.DoWork();

                //var myServiceAnother = serviceProvider.GetService<IAnotherService>();
                //myServiceAnother?.PerformAction();
            }
        }
    }
}
