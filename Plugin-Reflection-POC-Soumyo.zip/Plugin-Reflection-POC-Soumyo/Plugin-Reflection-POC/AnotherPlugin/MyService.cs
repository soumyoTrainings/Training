﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnotherPlugin
{
    public class MyService : IMyService
    {
        public void DoWork()
        {
            Console.WriteLine("MyPlugin is doing work!");
        }
    }
}
