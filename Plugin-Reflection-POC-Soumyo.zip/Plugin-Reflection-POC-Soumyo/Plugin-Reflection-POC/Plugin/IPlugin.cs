﻿using Microsoft.Extensions.DependencyInjection;

namespace Plugin
{
    public interface IPlugin
    {
        void RegisterPlugin(IServiceCollection services);
    }
}
